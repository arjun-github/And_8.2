package com.acadgild.customlistview;
import android.app.Activity;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.ListView;


public class MainActivity extends AppCompatActivity {

    private ListView listView;
    //defining two string array
    private String name[] = {
            "Rohit",
            "Shivam",
            "Abhishek",
            "Tarun"
    };

    private String phone_no[] = {
            "0123456789",
            "1122335678",
            "5676577656",
            "4577778686"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);//loading the main layout
        //binding name and phone-no with custom list
        Custom customList = new Custom(this, name,phone_no);
        listView = (ListView) findViewById(R.id.listView);
        listView.setAdapter(customList);//setting the adapter
    }


}